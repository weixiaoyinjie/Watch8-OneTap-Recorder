package com.watch8.onetaprecorder;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Environment;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Foreground microphone recording, started only from the short-lived Activity. */
public final class RecordingService extends Service {
    public static final String ACTION_TOGGLE = "com.watch8.onetaprecorder.TOGGLE";
    public static final String ACTION_STOP = "com.watch8.onetaprecorder.STOP";
    public static final String EVENT_RESULT = "com.watch8.onetaprecorder.RESULT";
    public static final String EXTRA_ERROR = "error";
    public static final String RECORDINGS_FOLDER = Environment.DIRECTORY_MUSIC + "/Watch8Recorder/";

    private static final String CHANNEL_ID = "watch8_mic_capture";
    private static final int NOTIFICATION_ID = 1001;
    private static volatile boolean recording = false;
    private MediaRecorder recorder;
    private Uri mediaUri;
    private ParcelFileDescriptor recordingFd;
    private boolean ownsForeground = false;

    public static boolean isRecording() { return recording; }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? "" : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            String failure = finishRecording();
            sendResult(failure);
            stopSelf(startId);
            return START_NOT_STICKY;
        }
        if (ACTION_TOGGLE.equals(action)) {
            if (recorder != null) {
                String failure = finishRecording();
                sendResult(failure);
                stopSelf(startId);
            } else {
                String failure = beginRecording();
                sendResult(failure);
                if (failure != null) stopSelf(startId);
            }
            return START_NOT_STICKY;
        }
        stopSelf(startId);
        return START_NOT_STICKY;
    }

    private String beginRecording() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return "麦克风权限未授权";
        }
        try {
            createChannel();
            // Android 14+ requires an actual microphone FGS prior to capture.
            startForeground(NOTIFICATION_ID, createNotification(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            ownsForeground = true;

            ContentValues values = new ContentValues();
            String filename = "Watch8Rec_" + new SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US)
                    .format(new Date()) + ".m4a";
            values.put(MediaStore.Audio.Media.DISPLAY_NAME, filename);
            values.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4");
            values.put(MediaStore.Audio.Media.RELATIVE_PATH, RECORDINGS_FOLDER);
            values.put(MediaStore.Audio.Media.IS_PENDING, 1);
            mediaUri = getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values);
            if (mediaUri == null) throw new IOException("无法创建录音文件");
            recordingFd = getContentResolver().openFileDescriptor(mediaUri, "w");
            if (recordingFd == null) throw new IOException("无法打开录音文件");

            if (android.os.Build.VERSION.SDK_INT >= 31) recorder = new MediaRecorder(this);
            else recorder = new MediaRecorder(); // For API 30 compatibility
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioChannels(1);
            recorder.setAudioSamplingRate(16000);
            recorder.setAudioEncodingBitRate(32000);
            recorder.setOutputFile(recordingFd.getFileDescriptor());
            recorder.setMaxFileSize(200L * 1024L * 1024L);
            recorder.setOnErrorListener((mr, what, extra) -> {
                String failure = finishRecording();
                sendResult(failure != null ? failure : "录音设备出错，已停止");
                stopSelf();
            });
            recorder.setOnInfoListener((mr, what, extra) -> {
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_FILESIZE_REACHED) {
                    String failure = finishRecording();
                    sendResult(failure != null ? failure : "录音文件已达到大小上限");
                    stopSelf();
                }
            });
            recorder.prepare();
            recorder.start();
            recording = true;
            return null;
        } catch (Exception ex) {
            abandonFile();
            removeForeground();
            return "录音失败：" + ex.getClass().getSimpleName();
        }
    }

    /** @return error text or null after successful finalized MP4/AAC recording. */
    private String finishRecording() {
        if (recorder == null) {
            removeForeground();
            recording = false;
            return null;
        }
        recording = false;
        boolean saved = true;
        try {
            recorder.stop();
        } catch (RuntimeException ex) {
            saved = false; // Very short recordings may lack a valid MP4 header.
        }
        try { recorder.reset(); } catch (RuntimeException ignored) { }
        recorder.release();
        recorder = null;
        closeFd();
        if (saved && mediaUri != null) {
            try {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Audio.Media.IS_PENDING, 0);
                getContentResolver().update(mediaUri, values, null, null);
            } catch (Exception ex) {
                saved = false;
            }
        }
        if (!saved) deleteCurrentFile();
        mediaUri = null;
        removeForeground();
        return saved ? null : "录音太短或保存失败，文件未保存";
    }

    private void abandonFile() {
        recording = false;
        if (recorder != null) {
            try { recorder.reset(); } catch (RuntimeException ignored) { }
            try { recorder.release(); } catch (Exception ignored) { }
            recorder = null;
        }
        closeFd();
        deleteCurrentFile();
        mediaUri = null;
    }

    private void closeFd() {
        if (recordingFd != null) {
            try { recordingFd.close(); } catch (IOException ignored) { }
            recordingFd = null;
        }
    }

    private void deleteCurrentFile() {
        if (mediaUri == null) return;
        try { getContentResolver().delete(mediaUri, null, null); }
        catch (Exception ignored) { }
    }

    private void removeForeground() {
        if (ownsForeground) {
            stopForeground(STOP_FOREGROUND_REMOVE);
            ownsForeground = false;
        }
    }

    private void sendResult(String error) {
        Intent update = new Intent(EVENT_RESULT).setPackage(getPackageName());
        if (error != null) update.putExtra(EXTRA_ERROR, error);
        sendBroadcast(update);
    }

    private void createChannel() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                getString(R.string.recording_channel), NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("录音时持续显示状态和停止按钮");
        channel.enableVibration(false);
        channel.setSound(null, null);
        nm.createNotificationChannel(channel);
    }

    private Notification createNotification() {
        Intent openManager = new Intent(this, ManagerActivity.class);
        openManager.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 20, openManager,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, RecordingService.class).setAction(ACTION_STOP);
        PendingIntent stopAction = PendingIntent.getService(this, 21, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notif_mic)
                .setContentTitle(getString(R.string.notification_title))
                .setContentText(getString(R.string.notification_text))
                .setContentIntent(content)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setSilent(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .addAction(new Notification.Action.Builder(R.drawable.ic_notif_mic,
                        "停止并保存", stopAction).build())
                .build();
    }

    @Override
    public void onDestroy() {
        // Gracefully finalize when the OS destroys the service normally.
        if (recorder != null) finishRecording();
        removeForeground();
        recording = false;
        super.onDestroy();
    }
}
