package com.watch8.onetaprecorder;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.widget.Toast;

/**
 * A briefly visible, transparent Activity is deliberately used as the entry point.
 * Android 14+ requires the microphone foreground service to be CREATED while
 * a calling activity is in a user-visible/while-in-use permission state.
 * No full-screen UI is drawn on subsequent launches.
 */
public final class ToggleActivity extends Activity {
    private static final int PERMISSION_REQUEST = 73;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean launched = false;
    private boolean completed = false;
    private boolean receiverRegistered = false;
    private boolean awaitingPermission = false;
    private boolean resumed = false;

    private final BroadcastReceiver resultReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!RecordingService.EVENT_RESULT.equals(intent.getAction())) return;
            if (completed) return;
            String error = intent.getStringExtra(RecordingService.EXTRA_ERROR);
            if (error != null && !error.isEmpty()) {
                Toast.makeText(ToggleActivity.this, error, Toast.LENGTH_LONG).show();
            }
            close();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        IntentFilter filter = new IntentFilter(RecordingService.EVENT_RESULT);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(resultReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(resultReceiver, filter);
        }
        receiverRegistered = true;
        handler.postDelayed(this::close, 7000L);
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        if (!launched && !awaitingPermission) checkAndToggle();
    }

    private void checkAndToggle() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            awaitingPermission = true;
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, PERMISSION_REQUEST);
            return;
        }
        // Notification permission is optional for the FGS itself; request once,
        // so ongoing recording can be displayed in the notifications area.
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                && !getPreferences(MODE_PRIVATE).getBoolean("notification_prompted", false)) {
            getPreferences(MODE_PRIVATE).edit().putBoolean("notification_prompted", true).apply();
            awaitingPermission = true;
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, PERMISSION_REQUEST);
            return;
        }
        launched = true;
        try {
            Intent service = new Intent(this, RecordingService.class);
            service.setAction(RecordingService.ACTION_TOGGLE);
            // Start from a resumed activity to satisfy Android's while-in-use rule.
            startForegroundService(service);
        } catch (Exception ex) {
            Toast.makeText(this, "启动录音失败：" + ex.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
            close();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != PERMISSION_REQUEST || completed) return;
        awaitingPermission = false;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            if (resumed) checkAndToggle();
        } else {
            Toast.makeText(this, "需要麦克风权限才能录音", Toast.LENGTH_SHORT).show();
            close();
        }
    }

    @Override
    protected void onPause() {
        resumed = false;
        super.onPause();
    }

    private void close() {
        if (completed) return;
        completed = true;
        finish();
        overridePendingTransition(0, 0);
    }

    @Override
    protected void onDestroy() {
        if (receiverRegistered) unregisterReceiver(resultReceiver);
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
