package com.watch8.onetaprecorder;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Compact, round-screen-aware Wear OS recording manager; normally shows 3-4 files per screen. */
public final class ManagerActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private LinearLayout content;
    private MediaPlayer player;
    private Uri playingUri;
    private Button playingButton;

    private static final class Entry {
        final Uri uri;
        final String name;
        final long size;
        final long seconds;
        final long duration;
        Entry(Uri uri, String name, long size, long seconds, long duration) {
            this.uri = uri; this.name = name; this.size = size;
            this.seconds = seconds; this.duration = duration;
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.BLACK);
        scroll.setVerticalScrollBarEnabled(false);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        // The inset keeps tappable controls within the circular display.
        content.setPadding(dp(32), dp(24), dp(32), dp(12));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        setContentView(scroll);
    }

    @Override protected void onResume() { super.onResume(); render(); }

    private void render() {
        content.removeAllViews();
        LinearLayout heading = horizontal();
        content.addView(heading, new LinearLayout.LayoutParams(-1, dp(30)));
        TextView title = label("录音管理", 18, Color.WHITE, true);
        heading.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        boolean recording = RecordingService.isRecording();
        TextView status = label(recording ? "● 录音中" : "● 已停止", 11,
                recording ? 0xFFFF7373 : 0xFF999999, true);
        heading.addView(status, new LinearLayout.LayoutParams(-2, -2));

        if (recording) {
            Button stop = button("停止并保存", dp(33), 12, 0xFF673033);
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(33));
            sp.bottomMargin = dp(5);
            content.addView(stop, sp);
            stop.setOnClickListener(v -> {
                Intent intent = new Intent(this, RecordingService.class).setAction(RecordingService.ACTION_STOP);
                startService(intent);
                handler.postDelayed(this::render, 550L);
            });
        }

        List<Entry> entries = readEntries();
        TextView count = label(entries.isEmpty() ? "录音保存在手表中" : "共 " + entries.size() + " 条 · 最近录音", 11, 0xFFAAAAAA, false);
        count.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams countParams = new LinearLayout.LayoutParams(-1, dp(22));
        content.addView(count, countParams);

        if (entries.isEmpty()) {
            TextView empty = label("暂无录音\n双击 Home 键开始", 12, 0xFF888888, false);
            empty.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(86));
            content.addView(empty, p);
            return;
        }
        for (Entry entry : entries) addEntry(entry);
    }

    private List<Entry> readEntries() {
        ArrayList<Entry> result = new ArrayList<>();
        String[] columns = {
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.SIZE, MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DURATION
        };
        String filter = MediaStore.Audio.Media.RELATIVE_PATH + "=? AND "
                + MediaStore.Audio.Media.IS_PENDING + "=0";
        try (Cursor cursor = getContentResolver().query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, columns, filter,
                new String[]{RecordingService.RECORDINGS_FOLDER},
                MediaStore.Audio.Media.DATE_ADDED + " DESC, " + MediaStore.Audio.Media._ID + " DESC")) {
            if (cursor == null) return result;
            while (cursor.moveToNext()) {
                long id = cursor.getLong(0);
                String name = cursor.getString(1);
                long size = cursor.isNull(2) ? 0 : cursor.getLong(2);
                long seconds = cursor.isNull(3) ? 0 : cursor.getLong(3);
                long duration = cursor.isNull(4) ? 0 : cursor.getLong(4);
                result.add(new Entry(ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id),
                        name, size, seconds, duration));
            }
        } catch (Exception e) {
            Toast.makeText(this, "读取录音失败", Toast.LENGTH_SHORT).show();
        }
        return result;
    }

    private void addEntry(Entry entry) {
        LinearLayout card = horizontal();
        card.setBackground(roundRect(0xFF171717, 11));
        card.setPadding(dp(9), dp(7), dp(8), dp(7));
        LinearLayout.LayoutParams outer = new LinearLayout.LayoutParams(-1, dp(54));
        outer.bottomMargin = dp(5);
        content.addView(card, outer);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(info, new LinearLayout.LayoutParams(0, -1, 1));
        String when = new SimpleDateFormat("MM/dd HH:mm", Locale.CHINA)
                .format(new Date(entry.seconds * 1000L));
        TextView title = label(when, 12, Color.WHITE, true);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        info.addView(title);
        String detail = (entry.duration > 0 ? readableDuration(entry.duration) + "  ·  " : "")
                + readableSize(entry.size);
        TextView sub = label(detail, 10, 0xFFAAAAAA, false);
        info.addView(sub);

        Button play = button(entry.uri.equals(playingUri) ? "■" : "▶", dp(36), 15, 0xFF363636);
        play.setContentDescription("播放或停止 " + entry.name);
        card.addView(play, iconParams(0));
        play.setOnClickListener(v -> togglePlayback(entry.uri, play));

        Button share = button("↗", dp(36), 17, 0xFF303030);
        share.setContentDescription("分享 " + entry.name);
        card.addView(share, iconParams(4));
        share.setOnClickListener(v -> share(entry));

        Button delete = button("×", dp(36), 19, 0xFF42272A);
        delete.setContentDescription("删除 " + entry.name);
        card.addView(delete, iconParams(4));
        delete.setOnClickListener(v -> confirmDeletion(entry));
    }

    private LinearLayout.LayoutParams iconParams(int marginStart) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(36), dp(36));
        p.leftMargin = dp(marginStart);
        return p;
    }

    private void togglePlayback(Uri uri, Button clicked) {
        if (uri.equals(playingUri)) { stopPlayback(); return; }
        stopPlayback();
        try {
            MediaPlayer mp = new MediaPlayer();
            player = mp;
            playingUri = uri;
            playingButton = clicked;
            clicked.setText("…");
            mp.setDataSource(this, uri);
            mp.setOnPreparedListener(ready -> {
                if (player != ready) return;
                ready.start();
                if (playingButton != null) playingButton.setText("■");
            });
            mp.setOnCompletionListener(done -> stopPlayback());
            mp.setOnErrorListener((bad, what, extra) -> {
                Toast.makeText(this, "录音播放失败", Toast.LENGTH_SHORT).show();
                stopPlayback();
                return true;
            });
            mp.prepareAsync();
        } catch (Exception ex) {
            stopPlayback();
            Toast.makeText(this, "录音无法播放", Toast.LENGTH_SHORT).show();
        }
    }

    private void stopPlayback() {
        if (player != null) {
            try { player.reset(); } catch (Exception ignored) { }
            try { player.release(); } catch (Exception ignored) { }
            player = null;
        }
        if (playingButton != null) playingButton.setText("▶");
        playingButton = null;
        playingUri = null;
    }

    private void share(Entry entry) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("audio/mp4");
        intent.putExtra(Intent.EXTRA_STREAM, entry.uri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(Intent.createChooser(intent, "分享录音")); }
        catch (Exception ex) { Toast.makeText(this, "没有可用的分享应用", Toast.LENGTH_LONG).show(); }
    }

    private void confirmDeletion(Entry entry) {
        new AlertDialog.Builder(this)
                .setTitle("删除这条录音？")
                .setNegativeButton("取消", (d, w) -> d.dismiss())
                .setPositiveButton("删除", (d, w) -> {
                    if (entry.uri.equals(playingUri)) stopPlayback();
                    try {
                        int count = getContentResolver().delete(entry.uri, null, null);
                        Toast.makeText(this, count > 0 ? "已删除" : "删除失败", Toast.LENGTH_SHORT).show();
                    } catch (Exception ex) {
                        Toast.makeText(this, "删除失败", Toast.LENGTH_SHORT).show();
                    }
                    render();
                }).show();
    }

    private LinearLayout horizontal() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }
    private TextView label(String text, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }
    private Button button(String text, int height, int sp, int fillColor) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        b.setGravity(Gravity.CENTER);
        b.setPadding(0, 0, 0, 0);
        b.setMinimumWidth(0);
        b.setMinimumHeight(0);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setBackground(roundRect(fillColor, 9));
        return b;
    }
    private GradientDrawable roundRect(int color, int radiusDp) {
        GradientDrawable rect = new GradientDrawable();
        rect.setColor(color);
        rect.setCornerRadius(dp(radiusDp));
        return rect;
    }
    private static String readableSize(long bytes) {
        if (bytes <= 0) return "—";
        if (bytes < 1024 * 1024) return Math.max(1, bytes / 1024) + "KB";
        return String.format(Locale.US, "%.1fMB", bytes / 1048576.0);
    }
    private static String readableDuration(long millis) {
        long seconds = millis / 1000L;
        return String.format(Locale.US, "%02d:%02d", seconds / 60L, seconds % 60L);
    }
    private int dp(float n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    @Override protected void onStop() { stopPlayback(); super.onStop(); }
    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        stopPlayback();
        super.onDestroy();
    }
}
